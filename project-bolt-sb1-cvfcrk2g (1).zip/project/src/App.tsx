import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Referrals from './pages/Referrals';
import Tasks from './pages/Tasks';
import Airdrops from './pages/Airdrops';
import Wallet from './pages/Wallet';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/referrals" element={<Referrals />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/airdrops" element={<Airdrops />} />
          <Route path="/wallet" element={<Wallet />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;