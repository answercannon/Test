import React from 'react';
import { Gift, Clock, AlertCircle } from 'lucide-react';

const Airdrops = () => {
  const currentAirdrop = {
    tokens: 5000,
    endsIn: '2d 14h',
    participants: 1234,
  };

  const history = [
    { date: '2024-03-01', amount: 1000, status: 'Claimed' },
    { date: '2024-02-15', amount: 750, status: 'Claimed' },
  ];

  return (
    <div className="min-h-screen py-8 px-4">
      <h1 className="text-3xl font-bold text-white mb-8">Airdrops</h1>
      
      {/* Current Airdrop */}
      <div className="bg-gray-800 rounded-xl p-6 mb-8 border border-purple-500/20">
        <div className="flex items-center gap-3 mb-4">
          <Gift className="w-6 h-6 text-purple-400" />
          <h2 className="text-xl font-bold text-white">Current Airdrop</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-700 rounded-lg p-4">
            <p className="text-gray-400">Available Tokens</p>
            <p className="text-2xl font-bold text-purple-400">{currentAirdrop.tokens}</p>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <p className="text-gray-400">Ends In</p>
            <p className="text-2xl font-bold text-purple-400">{currentAirdrop.endsIn}</p>
          </div>
          <div className="bg-gray-700 rounded-lg p-4">
            <p className="text-gray-400">Participants</p>
            <p className="text-2xl font-bold text-purple-400">{currentAirdrop.participants}</p>
          </div>
        </div>

        <button className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg">
          Participate Now
        </button>
      </div>

      {/* Requirements */}
      <div className="bg-gray-800 rounded-xl p-6 mb-8 border border-purple-500/20">
        <div className="flex items-center gap-3 mb-4">
          <AlertCircle className="w-6 h-6 text-purple-400" />
          <h2 className="text-xl font-bold text-white">Requirements</h2>
        </div>
        <ul className="space-y-2 text-gray-300">
          <li>• Complete all daily tasks</li>
          <li>• Have at least 3 active referrals</li>
          <li>• Hold minimum 100 TOKENS</li>
        </ul>
      </div>

      {/* History */}
      <div className="bg-gray-800 rounded-xl p-6 border border-purple-500/20">
        <div className="flex items-center gap-3 mb-4">
          <Clock className="w-6 h-6 text-purple-400" />
          <h2 className="text-xl font-bold text-white">History</h2>
        </div>
        <div className="space-y-4">
          {history.map((item, index) => (
            <div key={index} className="flex items-center justify-between py-2 border-b border-gray-700">
              <div>
                <p className="text-white">{item.date}</p>
                <p className="text-purple-400">{item.amount} TOKENS</p>
              </div>
              <span className="text-green-400">{item.status}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Airdrops;