import React, { useState, useCallback } from 'react';
import BoxerCharacter from '../components/BoxerCharacter';
import TokenDisplay from '../components/TokenDisplay';

const Home = () => {
  const [tokens, setTokens] = useState(0);
  const [tapsRemaining, setTapsRemaining] = useState(100);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleTap = useCallback(() => {
    if (tapsRemaining > 0) {
      setIsAnimating(true);
      setTokens(prev => prev + 1);
      setTapsRemaining(prev => prev - 1);
      
      setTimeout(() => {
        setIsAnimating(false);
      }, 150);
    }
  }, [tapsRemaining]);

  return (
    <div className="min-h-screen py-8 space-y-8">
      <h1 className="text-4xl font-bold text-center text-white mb-12">
        Boxer
      </h1>
      
      <BoxerCharacter onTap={handleTap} isAnimating={isAnimating} />
      
      <TokenDisplay tokens={tokens} tapsRemaining={tapsRemaining} />
    </div>
  );
};

export default Home;