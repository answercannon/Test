import React from 'react';
import { CheckCircle2, Twitter, MessageCircle, Youtube } from 'lucide-react';

const Tasks = () => {
  const tasks = [
    {
      id: 1,
      title: 'Follow on Twitter',
      icon: Twitter,
      reward: 100,
      completed: true,
    },
    {
      id: 2,
      title: 'Join Telegram Group',
      icon: MessageCircle,
      reward: 150,
      completed: false,
    },
    {
      id: 3,
      title: 'Subscribe to YouTube',
      icon: Youtube,
      reward: 200,
      completed: false,
    },
  ];

  return (
    <div className="min-h-screen py-8 px-4">
      <h1 className="text-3xl font-bold text-white mb-8">Daily Tasks</h1>
      
      <div className="space-y-4">
        {tasks.map((task) => (
          <div
            key={task.id}
            className="bg-gray-800 rounded-xl p-6 border border-purple-500/20 flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <task.icon className="w-8 h-8 text-purple-400" />
              <div>
                <h3 className="text-white font-semibold">{task.title}</h3>
                <p className="text-purple-400">{task.reward} TOKENS</p>
              </div>
            </div>
            <button
              className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                task.completed
                  ? 'bg-green-600 text-white cursor-default'
                  : 'bg-purple-600 hover:bg-purple-700 text-white'
              }`}
            >
              {task.completed ? (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  Completed
                </>
              ) : (
                'Verify'
              )}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Tasks;