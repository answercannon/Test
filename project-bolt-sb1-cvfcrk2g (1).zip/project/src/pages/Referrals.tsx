import React from 'react';
import { Share2, Users } from 'lucide-react';

const Referrals = () => {
  const referralStats = {
    totalReferrals: 12,
    activeReferrals: 8,
    totalEarned: 1500,
  };

  const referralLink = 'https://boxer.app/ref/user123';

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <h1 className="text-3xl font-bold text-white mb-8">Referrals</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-gray-800 rounded-xl p-6 border border-purple-500/20">
          <h3 className="text-gray-400">Total Referrals</h3>
          <p className="text-2xl font-bold text-purple-400">{referralStats.totalReferrals}</p>
        </div>
        <div className="bg-gray-800 rounded-xl p-6 border border-purple-500/20">
          <h3 className="text-gray-400">Active Referrals</h3>
          <p className="text-2xl font-bold text-purple-400">{referralStats.activeReferrals}</p>
        </div>
        <div className="bg-gray-800 rounded-xl p-6 border border-purple-500/20">
          <h3 className="text-gray-400">Total Earned</h3>
          <p className="text-2xl font-bold text-purple-400">{referralStats.totalEarned} TOKENS</p>
        </div>
      </div>

      {/* Referral Link */}
      <div className="bg-gray-800 rounded-xl p-6 mb-8 border border-purple-500/20">
        <h2 className="text-xl font-bold text-white mb-4">Your Referral Link</h2>
        <div className="flex items-center gap-4">
          <input
            type="text"
            value={referralLink}
            readOnly
            className="flex-1 bg-gray-700 text-white p-3 rounded-lg"
          />
          <button
            onClick={copyReferralLink}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-3 rounded-lg flex items-center gap-2"
          >
            <Share2 className="w-5 h-5" />
            Copy
          </button>
        </div>
      </div>

      {/* Referral Tree */}
      <div className="bg-gray-800 rounded-xl p-6 border border-purple-500/20">
        <h2 className="text-xl font-bold text-white mb-4">Referral Tree</h2>
        <div className="flex items-center justify-center py-12">
          <Users className="w-16 h-16 text-purple-400" />
        </div>
        <p className="text-center text-gray-400">Invite friends to see your referral tree grow!</p>
      </div>
    </div>
  );
};

export default Referrals;