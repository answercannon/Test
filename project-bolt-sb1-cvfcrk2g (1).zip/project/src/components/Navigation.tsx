import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Users, CheckSquare, Gift, Wallet } from 'lucide-react';

const Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { id: 'home', icon: Home, label: 'Home', path: '/' },
    { id: 'referrals', icon: Users, label: 'Referrals', path: '/referrals' },
    { id: 'tasks', icon: CheckSquare, label: 'Tasks', path: '/tasks' },
    { id: 'airdrops', icon: Gift, label: 'Airdrops', path: '/airdrops' },
    { id: 'wallet', icon: Wallet, label: 'Wallet', path: '/wallet' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-purple-800">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center p-2 rounded-lg transition-all ${
                location.pathname === item.path
                  ? 'text-purple-400 scale-110'
                  : 'text-gray-400 hover:text-purple-300'
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;