import React from 'react';

interface BoxerCharacterProps {
  onTap: () => void;
  isAnimating: boolean;
}

const BoxerCharacter: React.FC<BoxerCharacterProps> = ({ onTap, isAnimating }) => {
  return (
    <div
      className={`relative cursor-pointer transition-transform ${
        isAnimating ? 'scale-95' : 'scale-100'
      }`}
      onClick={onTap}
    >
      <div className="w-48 h-48 mx-auto relative">
        <img
          src="https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&q=80&w=400&h=400"
          alt="Boxer Character"
          className="rounded-full object-cover w-full h-full border-4 border-purple-500 shadow-lg shadow-purple-500/50"
        />
        {isAnimating && (
          <div className="absolute inset-0 animate-ping rounded-full bg-purple-500 opacity-20" />
        )}
      </div>
    </div>
  );
};

export default BoxerCharacter;