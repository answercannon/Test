import React from 'react';

interface TokenDisplayProps {
  tokens: number;
  tapsRemaining: number;
}

const TokenDisplay: React.FC<TokenDisplayProps> = ({ tokens, tapsRemaining }) => {
  return (
    <div className="text-center space-y-4">
      <div className="bg-gray-800 rounded-xl p-6 shadow-lg border border-purple-500/20">
        <h2 className="text-2xl font-bold text-purple-400">
          {tokens.toLocaleString()} TOKENS
        </h2>
        <p className="text-gray-400 text-sm mt-2">
          Daily Taps Remaining: {tapsRemaining}
        </p>
      </div>
      <button className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-all hover:scale-105 active:scale-95">
        Claim Tokens
      </button>
    </div>
  );
};

export default TokenDisplay;