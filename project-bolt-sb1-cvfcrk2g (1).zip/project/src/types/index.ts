export interface User {
  id: string;
  tokens: number;
  dailyTapsRemaining: number;
  totalReferrals: number;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  reward: number;
  completed: boolean;
  icon: string;
}

export interface MenuItem {
  label: string;
  icon: string;
  path: string;
}